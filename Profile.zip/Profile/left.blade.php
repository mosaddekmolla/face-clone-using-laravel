<div class="col-sm-3">
    <div class="sidebar">
        <li><a href="./dashboard.html" class="active">News Feed</a></li>
        <li><a href="./settings.html" class="active">Settings</a></li>
        <li><a href="{{route('logout')}}">Logout</a></li>

    </div>
</div>
